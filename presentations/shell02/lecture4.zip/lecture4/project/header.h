#ifndef __HEADER_H_
#define __HEADER_H_

// TODO: Add some macros here
#define VARIABLE 17 

#endif
