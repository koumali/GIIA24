#include <stdio.h>
#include <stdlib.h>

#include "header.h"

int main(void)
{
    // TODO: add functionality
    printf("well hello there\n");
    return EXIT_SUCCESS;
}
